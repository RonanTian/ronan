export const LOCAL = 'local'
export const HASH_ROUTE = "/personal-site/#/"