import photo from "./logo192.png"
import me from "./images/me.jpg"
export const IntroInfo = {
    greeting: "Hello, I'm",
    name: "Ryan Tian",
    title: ""
}

export const portraitInfo = {
    photo: me
}
