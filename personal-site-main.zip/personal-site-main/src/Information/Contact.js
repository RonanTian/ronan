import photo from "./logo192.png"
import qrImage from "./images/qr.png"
export const finalCall = "Feel free to email me to find out more!"
export const profilePhoto = photo
export const email = "ryantian64@gmail.com"
export const location = "Singapore"
export const linkedInURL = "https://www.linkedin.com/in/ryan-tian-jun/"
export const github = "https://github.com/ryantianj"

export const qrCode = qrImage
