import React from 'react'

const button = ({name, link}) => {
    return (
        <div>

        </div>
    )
}
export default button