import React from "react";
import "./Divisor.css"

const Divisor = () => {
    return (
        <div className="divisor"> </div>
    )
}
export default Divisor